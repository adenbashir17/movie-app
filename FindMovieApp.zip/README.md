
# Findmovie app — Modified (Teal theme)

This is a small Vue 3 + Vite app. I made minor style changes (colour palette and small UI tweaks)
so the app looks slightly different from the original you provided.

## Quick local run (development)

1. Make sure you have Node.js installed (recommend Node 18 or newer).
2. Open a terminal in the project root (this README is in the repo root).
3. Create an environment file with your TMDB v4 access token:

   ```
   # create a file named .env in the project root with the following content:
   VITE_TMDB_TOKEN=YOUR_TMDB_V4_BEARER_TOKEN_HERE
   ```

   > The app uses The Movie Database (TMDB) API. You must sign up at https://www.themoviedb.org/ and get a **v4 access token (Bearer)** from your account settings (Developer / API area).

4. Install dependencies:
   - Using npm:
     ```
     npm install
     ```
   - Or using pnpm (if you prefer):
     ```
     pnpm install
     ```

5. Run the dev server:
   ```
   npm run dev
   ```
   Then open the printed local URL (usually http://localhost:5173).

## Build for production
```
npm run build
npm run preview
```

If you run into an error about the token or API requests failing, double-check the `.env` value and that you used a **v4 access token (Bearer)**. The token should be set without quotes.

