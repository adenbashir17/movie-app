<template>
  <div class="error-page">
    <h1>Error 404</h1>
    <h2>😵‍💫🤖</h2>
  </div>
</template>
<style>
.error-page {
  text-align: center;
  h1 {
    font-size: clamp(60px, calc(8.654vw + 10.154px), 96px);
  }

  h2 {
    font-size: clamp(80px, calc(8.654vw + 10.154px), 96px);
  }
}
</style>
