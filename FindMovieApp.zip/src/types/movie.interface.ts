export interface Movie {
  id: number
  title: string
  release_date: string
  poster_path: string
  rating: number
  overview: string
}
